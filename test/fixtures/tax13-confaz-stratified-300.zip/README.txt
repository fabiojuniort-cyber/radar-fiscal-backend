TriBusca TAX13-ARCH-02: OFFLINE corpus for structural/regression tests.
Source: user-provided Confaz.zip. Source URLs and original HTTP SHA are asserted by archive, not independently verified.
Each XML includes normalized full text + escaped body HTML. The .html file is extracted official page BODY,
not the entire original HTTP response. It does NOT match original HTTP SHA.
The original XML is unmodified. Document text validation cannot establish CURRENT legal force.
Do NOT import to production; do NOT create positive LegalProof V2 from these samples automatically.
Some HTML files intentionally exceed 2 MiB; treat as negative size-limit tests.
The test suite should fail closed and report unsupported documents explicitly.
